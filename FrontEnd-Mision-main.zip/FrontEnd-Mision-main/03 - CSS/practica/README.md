# Práctica CSS

Que onda explorers!

En esta semana vimos como meterle estilos a nuestras páginas y hacer que tomen personalidad completa.

Para esta práctica necesito que clonen la página que está en el siguiente enlace [Link del diseño](./landingVacunaci%C3%B3n.png) by [Adhiari Subekti](https://dribbble.com/Adhiari_is)

Como pueden ver es una página de vacunación y en estos momentos que se está poniendo la tercer dosis en varios estados de la república y que en algunos otros se está poniendo la segunda o incluso la primera sigue siendo muy importante recordar toda esta información.

La práctica consiste en lo siguiente:

- Planeación de campaña de vacunación (Un poco de mercadotecnia para llegar al sitio)
- Maquetación del sitio con HTML
- Estilos con CSS (Lo más acercado posible, pueden ser otras imágenes, íconos o colores, pero tiene que ser lo más cercano que puedas)

Bonus:
- Bonus de diseños o páginas adicionales (Totalmente a tu creatividad)
- Bonus de despliegue de la página 

## El 11 de Marzo se subirá el Form para que entreguen las prácticas y tienen hasta el 13 de Marzo a las 12:00 de la noche para entregarlas. 
***¡Vámonos hasta el espacio y más allá Explorers!***

