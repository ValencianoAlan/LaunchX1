# HTML

Bienvenido Explorer, llegamos al primer vuelo de tu misión de FrontEnd y empezamos a programar con HTML.

HTML es el lenguaje que nos permite darle estructura a nuestras páginas web y que nos da la oportunidad de darle un esqueleto a nuestros sitios.

En este módulo veremos las siguientes cosas.

2. **HTML**
    - [Qué es HTML y estructura de archivo](./temario/1.-queEsHMTL.md)
	- [Etiquetas básicas](./temario/2.-etiquetasBasicas.md)
	- [Elementos compuestos](./temario/3.-elementosCompuestos.md)
	- [Acomodo y navegación](./temario/4.-acomodoNavegacion.md)
    - [Propiedades de etiquetas](./temario/5.-propiedades.md)

Para entrar a los contenidos solo tienes que dar click en el título y empezará la aventura.

***¡Vámonos hasta el espacio y más allá Explorers!***
