# JS

## Aquí haremos que nuestras páginas tengan funcionalidad

Les dejé unos programas con los ejemplos que estuvimos viendo en los diferentes lives.

- [Introducción a Programación con JS](./programas/1.-intro.js)
- [Funciones y Excepciones](./programas/2.-funciones.js)
- [JS en el navegador (DOM)](./programas/3.-navegador.js)
- [Pokedex](./programas/4.-pokedex.js)

Recuerden que para correrlos necesitan también los programas de HTML que están en el siguiente link [Carpeta de programas](./programas/)
## Práctica

[Este es el link de la práctica](./practica/README.md)
