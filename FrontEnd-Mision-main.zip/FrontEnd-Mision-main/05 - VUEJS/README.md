# Vue JS

Vue es uno de los frameworks top 3 que nos permiten hacer que nuestras plataformas y aplicaciones cobren vida y tengamos las posibilidades de crear, desarrollar y lanzar al mundo cosas increibles.

## Programas

- [Vue desde CDN](./programas/CDN/app.js)
- [Vue con CLI](./programas/CLI/App.vue)
- [VUEX](./programas/VUEX/App.vue)

Estos son los programas con los ejemplos que estuvimos viendo en los diferentes lives.

## Práctica

[Este es el link de la práctica](./practica/README.md)
