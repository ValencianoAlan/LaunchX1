
export const getPasteles = ( state ) => {
	return state.pasteles
}
