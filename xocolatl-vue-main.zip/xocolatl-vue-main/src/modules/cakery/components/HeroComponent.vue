<template>
    <div class="col-3 ">            
            <div class="aside">
              <img src="@/assets/img/flash-sale.png" alt="" width="100px" class="hero" />
              <h1>Promociones</h1>
              <br />
              <h2>Martes de 2x1</h2>
              <p>Haz tu pedido en línea</p>
              <br />
              <h2>Xocolatl Special</h2>
              <p>Prueba nuestro nuevo pastel de 4 tipos de chocolate</p>
            </div>
          </div>
  
        <div class="col-5">
          <h1>Pasteleria Xocolatl</h1>
          <br />
          <p>¡Porque todo buen recuerdo comienza con un pastel!</p>
        </div>
        <div class="col-5">
          <img
            src="@/assets/img/hero.gif"
            alt="hero image"
            width="380px"
            class="hero"
          />
        </div>
</template>