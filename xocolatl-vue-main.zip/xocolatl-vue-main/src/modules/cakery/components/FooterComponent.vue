<template>
  <footer class="footer">
    <p class="aranzazu">
      &#169; Copyright 2022 Todas las imagenes son de mi pasteleria favorita
      <a href="https://aranzazu.com/" class="aranzazu" target="_blank">
        Aranzazu
      </a>
      es con fines educativos
      <a href="https://github.com/doguedogue" class="github" target="_blank">
        @doguedogue
      </a>
    </p>
  </footer>
</template>

<style scoped>

.footer {
    background-color: #161b22;
    color: #ffffff;
    text-align: center;
    font-size: 12px;
    position: fixed;
    padding: 10px 10px 0px 10px;
    bottom: 0;
    width: 100%;
    height: 40px;
}


p.aranzazu {
    color:gray;
    font-size: 11px;
    text-decoration: none;
}
.aranzazu {
    color:yellowgreen;
    font-size: 11px;
    text-decoration: none;
}
</style>