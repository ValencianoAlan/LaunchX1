<template>
    <header class="header">
      <a href="index.html">
        <img
          class="center"
          src="@/assets/img/xocolatl_logo.png"
          alt="Logo Xocolatl"          
        />
      </a>
    </header>
</template>   

<style scoped>
.header {
    background-color: #161b22;
    color: #ffffff;
    padding: 15px;
    text-align:center;
    height: 234px;
}

.center {
    width: 200px;
}
</style>
