<template>
  <div class="col-6">
    <h1>Sucursales</h1>
    <iframe
      src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d120475.63827592063!2d-99.18765239696162!3d19.33172007885955!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1saranzazu%20cdmx!5e0!3m2!1ses!2smx!4v1646451251599!5m2!1ses!2smx"
      width="380"
      height="380"
      style="border: 0"
      allowfullscreen=""
      loading="lazy"
    ></iframe>
  </div>

  <div class="col-3 right">
    <div class="aside">
      <h2>Teléfono</h2>
      <p>01 800 XOCOLATL</p>
      <br />
      <h2>Horarios de Atención</h2>
      <p>10 am a 9pm</p>
      <p>365 días del año</p>
      <br />
      <h2>Correo Electrónico</h2>
      <p>atencion@xocolatl.com</p>
    </div>
  </div>
  <div class="col-4 blanco"></div>
</template>



<style scoped>
.aside {
  background-color: #161b22;
  padding: 15px;
  color: #ffffff;
  text-align: center;
  font-size: 14px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24);
  border-radius: 5px;
  border-width: 1px;
  border-style: solid;
  border-color: #1d2228;
}
.blanco {
  height: 100px;
}
</style>