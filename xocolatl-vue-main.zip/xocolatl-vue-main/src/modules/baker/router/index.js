

export default {
  name: 'baker',
  component: () => import(/* webpackChunkName: "BakerLayout" */ '@/modules/baker/layout/BakerLayout'),
  children: [

  ]
}
