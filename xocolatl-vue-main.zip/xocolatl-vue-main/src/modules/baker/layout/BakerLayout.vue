<template>
    <h1>Baker Layout</h1>
</template>