<template>
    <div class="counter">
      {{ $store.state.counter }}
    </div>
</template>

<script>
export default {
  name: 'Counter'
}
</script>